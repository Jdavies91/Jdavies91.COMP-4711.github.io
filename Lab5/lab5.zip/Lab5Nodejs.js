const fetch = require('node-fetch');



fetch('https://jdavies91.github.io')
    .then(res => res.text())
    .then(body => console.log(body));